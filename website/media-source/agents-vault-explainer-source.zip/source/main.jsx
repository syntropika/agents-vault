import React from 'react';
import {createRoot} from 'react-dom/client';
import {CompositionStage,useComposition,Captions} from './assets/catalog/native-composition/runtime/motion/animations.jsx';
import captions from './captions.json';
import avMark from './brand/av-mark.svg';
import avGeometry from './brand/av-geometry.json';
const clamp=x=>Math.max(0,Math.min(1,x));
const ease=x=>1-Math.pow(1-clamp(x),3);
const lerp=(a,b,x)=>a+(b-a)*ease(x);
const sceneOpacity=(t,a,b)=>clamp((t-a)/.45)*(b===37?1:clamp((b-t)/.35));
const icon=(size=34)=><svg width={size} height={size} viewBox="0 0 40 40" fill="none"><rect x="4" y="4" width="32" height="32" rx="10" stroke="currentColor" strokeWidth="2"/><path d="m12 14 6 6-6 6m10 0h7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const brandIcon=(size=34)=><img src={avMark} width={size} height={size} alt="" aria-hidden="true" style={{display:"block"}}/>;
function IntroBrand({size,time}){const separation=1-ease((time-.55)/.85);return <svg width={size} height={size} viewBox={avGeometry.viewBox} aria-hidden="true" style={{display:"block"}}><rect {...avGeometry.tile}/><g transform={avGeometry.placement} fill={avGeometry.fill}>{avGeometry.paths.map((p,i)=><path key={i} d={p.d} fillRule={p['fill-rule']} transform={`translate(${(i===0?-6:6)*separation} ${(i===0?-4:4)*separation})`}/>)}</g></svg>;}
function Card({x,y,w=400,h=260,children,style={}}){return <div className="card" style={{left:x,top:y,width:w,height:h,...style}}>{children}</div>}
function Title({eyebrow,children}){return <div className="heading"><div className="eyebrow">{eyebrow}</div><h1>{children}</h1></div>}
function Tag({children,bright=false}){return <span className={'tag'+(bright?' bright':'')}>{children}</span>}
function Artwork(){const {T:t}=useComposition();
const review=t>=15.5&&t<23.5; const approved=t>=21.3; const move=ease((t-25.8)/2.8); const injected=t>=28.6;
return <div className="art">
<style>{`
.art{position:relative;width:1280px;height:720px;background:#171717;color:#f5f5f5;font-family:Inter,system-ui,sans-serif;font-weight:500;overflow:hidden}
.mast{position:absolute;left:52px;right:52px;top:32px;display:flex;align-items:center;justify-content:space-between;color:#d5d5d5;font-size:19px}.mast-left{display:flex;align-items:center;gap:12px}.mast-right{display:flex;gap:10px}.tag{display:inline-block;border:1px solid #4a4a4a;border-radius:30px;padding:6px 13px;font-size:17px;color:#ccc;white-space:nowrap}.bright{background:#f5f5f5;color:#171717;border-color:#f5f5f5}
.heading{position:absolute;left:66px;top:104px}.eyebrow{font-size:18px;letter-spacing:1.4px;color:#aaa;text-transform:uppercase;margin-bottom:10px}h1{font-size:44px;line-height:1.08;letter-spacing:-1.6px;font-weight:500;margin:0}h2{font-size:27px;letter-spacing:-.5px;font-weight:500;margin:0 0 17px}.card{position:absolute;border:1px solid #494949;background:#212121;border-radius:24px;padding:28px;box-shadow:0 22px 50px #11111140}.label{font-size:16px;letter-spacing:1px;color:#aaa;text-transform:uppercase;margin-bottom:16px}.code{font-family:ui-monospace,monospace;font-size:21px;line-height:1.6;white-space:pre}.subtle{color:#aaa}.small{font-size:20px;line-height:1.45;color:#c5c5c5}.row{display:flex;justify-content:space-between;gap:25px;font-size:20px;padding:10px 0;border-top:1px solid #393939}.row:first-child{border:0}.row span:first-child{color:#aaa}.scene{position:absolute;inset:0}.note{position:absolute;font-size:22px;color:#ccc}.track{position:absolute;height:2px;background:#555;transform-origin:left}.dot{position:absolute;display:grid;place-items:center;border:1px solid #707070;background:#2f2f2f;border-radius:18px;width:68px;height:58px;color:#f5f5f5}.footer{position:absolute;left:52px;right:52px;bottom:25px;height:3px;background:#393939;border-radius:3px;overflow:hidden}.bar{height:100%;background:#d0d0d0}.caps{line-height:1.4 !important;max-width:1090px;margin:0 auto;text-align:center;}
`}</style>
<div className="mast"><div className="mast-left">{brandIcon(30)}<span>Agents Vault</span></div><div className="mast-right"><Tag>Illustrative synthetic data</Tag></div></div>
<div className="scene" style={{opacity:sceneOpacity(t,0,4.5)}}>
<div className="heading" style={{top:158,transform:`translateY(${lerp(28,0,t/.9)}px)`}}><h1 style={{fontSize:66,marginTop:31}}>Give every credential<br/>a deliberate path.</h1><div className="small" style={{marginTop:24}}>Project values, references, and reviewed CLI actions.</div></div>
<Card x={lerp(850,800,t/1.2)} y={160} w={370} h={295} style={{transform:`rotate(${lerp(5,0,t/1.2)}deg)`}}><div className="label">av.toml</div><div className="code">APP_ENV = "dev"<br/><br/><span className="subtle">SERVICE_TOKEN</span><br/>secret://demo/token</div></Card>
<div className="dot" style={{left:lerp(840,909,t/1.4),top:lerp(490,488,t/1.4),width:110,height:80}}><IntroBrand size={53} time={t}/></div>
</div>
<div className="scene" style={{opacity:sceneOpacity(t,4.5,10)}}><Title eyebrow="01 / Declare">Readable configuration.<br/>Unresolved references.</Title>
<Card x={66} y={260} w={550} h={274}><div className="label">av.toml · schematic excerpt</div><div className="code">[values.APP_ENV]<br/>value = "development"<br/><br/>[values.SERVICE_TOKEN]<br/>secret = "secret://demo/token"</div></Card>
<div className="track" style={{left:616,top:393,width:95}}/><div className="dot" style={{left:lerp(605,665,(t-5.6)/1.3),top:365,width:54,height:54,opacity:clamp((t-5.5)/.4)}}>→</div>
<Card x={711} y={292} w={502} h={213} style={{opacity:clamp((t-5.8)/.55)}}><div className="label">av placeholders</div><div className="code" style={{fontSize:19}}>APP_ENV="development"<br/>SERVICE_TOKEN="&lt;AV_SECRET:…&gt;"</div><div className="small" style={{marginTop:21}}>No credential resolution.</div></Card>
</div>
<div className="scene" style={{opacity:sceneOpacity(t,10,15.5)}}><Title eyebrow="02 / Grant direct delivery">References request access.<br/>Grants permit release.</Title>
<Card x={66} y={260} w={456} h={284}><div className="label">New credential</div><h2>Release grants: {t<12.7?'0':'1'}</h2><Tag bright={t>=12.7}>{t<12.7?'Default deny':'Explicit trusted command'}</Tag><div className="small" style={{marginTop:24}}>Executable + arguments<br/>reviewed by the operator.</div></Card>
<div className="track" style={{left:522,top:400,width:224}}/><div className="dot" style={{left:lerp(548,686,(t-12.9)/1.2),top:371}}>{t<12.7?'×':'→'}</div>
<Card x={746} y={295} w={468} h={225}><div className="label">Direct environment delivery</div><h2>{t<13.8?'Waiting for permission':'Real value delivered'}</h2><div className="small">The recipient can read and reveal it.<br/>Trust the command and its code.</div></Card>
</div>
<div className="scene" style={{opacity:sceneOpacity(t,15.5,23.5)}}><Title eyebrow="03 / Review a synthetic proxy action">Approve the exact frozen action.</Title>
<Card x={66} y={237} w={470} h={329}><div className="label">Original waiting CLI</div><div className="code" style={{fontSize:20}}>av run --<br/>/absolute/demo-client fetch</div><div style={{marginTop:24}}><Tag bright={approved}>{approved?'Approved · one attempt':'Pending decision'}</Tag></div><div className="small" style={{marginTop:23}}>The live CLI owns execution.<br/>A request ID is review context.</div></Card>
<div className="track" style={{left:536,top:401,width:115}}/><div className="dot" style={{left:lerp(537,583,(t-16.6)/1.2),top:372,width:56}}>{approved?'✓':'…'}</div>
<Card x={651} y={237} w={562} h={329} style={{transform:`translateY(${lerp(20,0,(t-15.5)/.8)}px)`}}><div className="label">Frozen review · synthetic example</div><div className="row"><span>Command</span><span>/absolute/demo-client · fetch</span></div><div className="row"><span>Destination</span><span>api.example.test</span></div><div className="row"><span>Credential version</span><span>service/work @ 1</span></div><div className="row"><span>Runtime / quotas</span><span>30s · 1 connection · 3 requests</span></div><div style={{marginTop:17,textAlign:'right'}}><Tag bright={approved}>{approved?'✓ Approved for this attempt':'Review → Approve'}</Tag></div></Card>
</div>
<div className="scene" style={{opacity:sceneOpacity(t,23.5,31)}}><Title eyebrow="04 / Deliver through the broker">Placeholder in the command.<br/>Credential inserted upstream.</Title>
<Card x={66} y={280} w={300} h={258}><div className="label">Approved CLI</div><div style={{marginBottom:14}}>{icon(39)}</div><h2>Placeholder</h2><div className="small">Temporary proxy<br/>capability + settings</div></Card>
<Card x={490} y={280} w={300} h={258}><div className="label">Local broker</div><div style={{position:"absolute",top:28,right:28}}>{brandIcon(28)}</div><h2>Synthetic<br/>credential</h2><div className="small" style={{marginTop:23}}>{injected?'Injects for exact host':'Held by the broker'}<br/>Bound by time + quotas</div></Card>
<Card x={914} y={280} w={300} h={258}><div className="label">Illustrative destination</div><h2>api.example.test</h2><div className="small" style={{marginTop:32}}>{injected?'Request + injected':'Waiting for the'}<br/>{injected?'synthetic credential':'approved request'}</div></Card>
<div className="track" style={{left:366,top:411,width:124}}/><div className="track" style={{left:790,top:411,width:124}}/>
<div className="dot" style={{left:lerp(371,422,(t-24.4)/1.1),top:384,width:54,height:54,opacity:t<27?1:0}}>→</div>
<div className="dot" style={{left:lerp(795,856,(t-27.6)/1.05),top:384,width:54,height:54,opacity:clamp((t-27.4)/.4)}}>{injected?'✓':'→'}</div>
</div>
<div className="scene" style={{opacity:sceneOpacity(t,31,37)}}><Title eyebrow="Current boundaries">Explore the mechanism.<br/>Understand the limits.</Title>
<Card x={66} y={264} w={548} h={271}><div className="label">Proxy use</div><h2 style={{fontSize:31}}>Keep proxy credentials synthetic.</h2><div className="small" style={{marginTop:28}}>Protected production credential custody<br/>remains a release gate.</div></Card>
<Card x={645} y={264} w={568} h={271}><div className="label">Know what approval means</div><h2 style={{fontSize:31}}>Host commands are not confined.</h2><div className="small" style={{marginTop:28}}>Exact host + time + quotas<br/>do not restrict every host resource.</div></Card>
</div>
<Captions items={captions} style={{fontSize:25,fontWeight:500,left:66,right:66,bottom:56,color:'#ededed',textShadow:'none',lineHeight:1.4}}/>
<div className="footer"><div className="bar" style={{width:`${t/37*100}%`}}/></div>
</div>}
createRoot(document.getElementById('root')).render(<CompositionStage width={1280} height={720} bg="#171717" fps={30} autoplay={true} source={true} scenes={window.CODEX_SCENES} playback={window.CODEX_PLAYBACK} persistKey="av-explainer-20261007"><Artwork/></CompositionStage>);
