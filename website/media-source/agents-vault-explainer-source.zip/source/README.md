# Agents Vault explainer source

A 37-second English motion graphic built with Forma's native CompositionStage runtime. It uses local React, local fonts, one authored timeline, finite playback, and deterministic seek. The bundled index.html runs without an external service. The rendered video is intentionally silent and has burned captions.

Edit main.jsx for visual composition and script.json for the canonical caption text. Keep captions.json, WebVTT, and transcript text synchronized with those script segments. Scene duration and repeat settings are declared in index.html. Rebuild bundle.js using the installed Forma launcher:

```sh
node "$FORMA_ROOT/scripts/forma.mjs" build main.jsx bundle.js --overwrite
node "$FORMA_ROOT/scripts/forma.mjs" preview . --port 0 --motion-file index.html
```

Export using the loopback URL printed by the preview helper and video.json. The exporter refuses to overwrite an existing output; choose a new filename for a revised cut.

```sh
node "$FORMA_ROOT/scripts/forma.mjs" export video "$PREVIEW_URL" explainer.mp4 --config video.json --capture-method fast
node "$FORMA_ROOT/scripts/forma.mjs" export html index.html explainer-editable.html
```

The standalone HTML export contains the bundled runtime and local font. The source folder contains editable JSX and resource provenance; bundled HTML alone does not replace that source. All example values, command recipes, destinations, versions and limits are illustrative synthetic data. Synthetic-only proxy use and protected custody limits are factual boundaries and must remain visible. The diagram is a schematic rather than a screen recording.

The video captions are also supplied as WebVTT for the website player. Burned captions mean external tracks are optional for visual viewing; attaching the track also gives viewers selectable captions and an accessibility transcript. Keep the English transcript available beside the player.

Runtime resource provenance: forma-catalog:native-composition. Font license and resource licenses are included in assets/catalog/native-composition/.
