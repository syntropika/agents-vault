# Production notes

Audience: developers and operators evaluating local project configuration and credential access.

Format: 37-second, 1280 × 720, 30 fps silent website explainer. English burned captions, matching WebVTT, and transcript. No avatar or stock footage. Native Forma CompositionStage owns all timing; local bundled React and fonts keep the source portable.

Direction: neutral #171717 background, #212121 cards, #2f2f2f controls, rounded geometry, readable white type. A recurring CLI arrow follows the causal sequence. All data and values are illustrative synthetic examples. The diagram simplifies the interface and is not a screen recording.

Evidence: PRODUCT.md and the public configuration/delivery, action/approval, limits/trust, and landing documents. Snapshots and hashes are supplied in evidence-map.json. No certification, benchmark, native keyring, cloud dependency, or named harness compatibility claims.

Voice capability: the available curated speech voices advertise Spanish locales only. English narration was not generated. Silence is intentional; captions carry the full argument.

Reading holds: opening 0–4.5s; configuration 4.5–10s; direct delivery 10–15.5s; frozen proxy approval 15.5–23.5s; broker delivery 23.5–31s; limits 31–37s. The runtime JSON scene literals are authoritative. One finite pass; ending holds its last frame.

The example recipe uses an illustrative executable, destination, version, duration, connection quota, and request quota. It implies no installed recipe or provider acceptance. The default-deny illustration concerns credential release grants. Exact synthetic action approval authorizes one attempt by the original waiting CLI connection. The child receives temporary proxy authority; upstream credential injection does not confine host resources.

## Completed verification

The final MP4 was exported through Forma: 1,110 frames, 37 seconds, 1280 × 720, 30 fps, with no exporter flags and no repeated captured frames. Source forward/backward seek produced matching screenshot hashes. All five scene boundaries were sampled at −0.15 seconds, the boundary, and +0.15 seconds in both the composition and the encoded MP4. The final encoded video completed one uninterrupted browser playback to 37 seconds without a media error; seven playback frames and the full encoded contact sheet were visually inspected. The WebM decoded completely through FFmpeg. Poster images were extracted from the actual final MP4 at 2.5 seconds. Caption/script alignment, final caption end time, local font readiness, runtime errors, desktop/mobile overflow, English prose, and absence of local operational paths in the authored source were checked.

No speech or audio listening check applies: both shipping formats are intentionally silent. Visual inspection covered actual encoded frames and sampled playback, rather than an audio assessment or provider acceptance test.

## Current boundaries revision

The shipping revision uses no product maturity badges or maturity words. The final section is labeled “Current boundaries” and “Proxy use.” Synthetic-only proxy use, protected production custody as a release gate, and host confinement limitations remain visible. All 37-second exports and posters are rendered from this neutral Forma source. Historical evidence snapshots retain their original text and hashes and are excluded from the shipping source ZIP. Poster provenance records extraction at 2.5 seconds from the rendered MP4; no generative raster model is used.

## Opening and portability correction

The opening overline was removed from the composition and poster. The opening headline retains its original top coordinate of 189 pixels; its supporting content and all later scenes retain their authored composition. The source catalog manifest destination is the relative path source/assets/catalog/native-composition. A recursive source check includes hidden metadata files and verifies that no local host or user path is packaged.

## Canonical brand mark

The canonical closed two-piece AV enclosure appears in the persistent header, opening brand tile, and broker card. The exact path geometry is preserved, with lavender #c4a7ff and ink #241735. The opening tile performs one closure from slight separation during 0.55–1.4 seconds; other brand marks remain static. There is no repeated motion cycle. Explicit command terminal icons retain their CLI meaning. Brand assets and parsed canonical path data are local and bundled. Caption text, scene timing, factual claims, and supporting surfaces retain their authored content.
